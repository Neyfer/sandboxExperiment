<?php
/**
 *
 * This file is part of Aura for PHP.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 *
 */
namespace Aura\Html;

/**
 *
 * Package-level exception.
 *
 * @package Aura.Html
 *
 */
class Exception extends \Exception
{
}
