<?php
/** doc */
function a(string $a): string
{
}

/** doc */
function b(string $b): string
{
}

/** doc */
function c(string $c): string
{
}
