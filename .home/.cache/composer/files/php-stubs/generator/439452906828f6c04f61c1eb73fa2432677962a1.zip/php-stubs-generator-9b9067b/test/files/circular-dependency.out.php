<?php
class B extends \A
{
}
class A extends \B
{
}
class C extends \C
{
}
