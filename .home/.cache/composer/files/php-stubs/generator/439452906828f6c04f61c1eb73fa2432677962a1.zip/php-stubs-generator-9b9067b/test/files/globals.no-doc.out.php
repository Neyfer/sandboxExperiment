<?php
$c = 'c' . 'c';

$d = 'd' . 'd';
