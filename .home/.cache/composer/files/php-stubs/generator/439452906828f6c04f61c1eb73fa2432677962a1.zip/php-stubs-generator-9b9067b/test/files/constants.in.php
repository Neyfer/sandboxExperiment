<?php

/** doc */
const FOO = 'bar';

/** doc */
define('FIZ', 'BUZ');

const A = 1, B = 2;
