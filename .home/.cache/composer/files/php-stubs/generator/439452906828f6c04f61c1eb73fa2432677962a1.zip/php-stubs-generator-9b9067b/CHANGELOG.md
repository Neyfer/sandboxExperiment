# Changelog

## [0.5] - 2018-04-13
### Added
- `--nullify-globals` option: converts all global variable assignments to `null`.

## [0.4] - 2018-03-17
### Fixed
- Issued a release with the changelog up-to-date.

## [0.3] - 2018-03-17
### Changed
- All function, class, interface, and trait declarations will be extracted from if statements, rather than just the first statement.

### Fixed
- Class, interface, and trait declarations are now always output in a valid order.

## [0.2] - 2018-02-18
### Added
- This changelog!

### Fixed
- Class and constant references will now be fully qualified where appropriate.

## [0.1] - 2018-02-12
- Initial release.
