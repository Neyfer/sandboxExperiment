<?php
/** doc */
$a = \null;

/** @doc */
$b = \null;

$c = \null;

$d = \null;
