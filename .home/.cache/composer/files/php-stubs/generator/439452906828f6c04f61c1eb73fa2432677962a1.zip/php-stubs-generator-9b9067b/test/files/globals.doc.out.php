<?php
/** doc */
$a = 'a' . 'a';

/** @doc */
$b = 'b' . 'b';
