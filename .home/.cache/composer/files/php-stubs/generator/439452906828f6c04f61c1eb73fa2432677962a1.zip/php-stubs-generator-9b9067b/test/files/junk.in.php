None of this junk should be included!
<?php

hello();

$say->helloWorld();

Say::helloWorld();

new Say();

if ($foo) {
    bar();
} elseif ($buz) {
    baz();
}

?>
Some more HTML!
<?php

switch ($foo) {
    case 'bar':
        buz();
        break;
}

'Pointless expression :)';

exit;

echo 'sup';

return [
    'foo'
];
