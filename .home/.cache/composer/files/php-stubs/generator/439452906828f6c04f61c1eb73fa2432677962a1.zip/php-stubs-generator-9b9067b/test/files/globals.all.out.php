<?php
/** doc */
$a = 'a' . 'a';

/** @doc */
$b = 'b' . 'b';

$c = 'c' . 'c';

$d = 'd' . 'd';
