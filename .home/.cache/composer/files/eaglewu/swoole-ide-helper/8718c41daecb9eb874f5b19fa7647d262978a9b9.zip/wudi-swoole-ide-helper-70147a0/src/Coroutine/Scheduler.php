<?php


namespace Swoole\Coroutine;


/**
 * 协程定时器
 * Class Scheduler
 * @package Swoole\Coroutine
 */
class Scheduler
{
    /**
     * 增加一个定时器
     * @param callable $func
     * @param $params
     */
    public static function add(callable $func, $params): void{

    }


    public static function parallel(callable $func, $params){

    }

    /**
     * @return bool
     */
    public static function start(){

    }


    public function set(array $settings){

    }
}