<?php

namespace Swoole\Server;

/**
 * Class Port
 * @package Swoole\Server
 * -
 */
class Port
{
    /**
     * @var int
     */
    public $sock;

    /**
     * @var int
     */
    public $port;

    /**
     * @param $event_name
     * @param callable $callback
     */
    function on($event_name, callable $callback)
    {

    }

    /**
     * @param $setting
     */
    function set($setting)
    {

    }
}

# end of file
